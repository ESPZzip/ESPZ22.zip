// Cargar usuario logueado
window.onload = function () {
  let user = JSON.parse(sessionStorage.getItem("currentUser"));
  if (!user) {
    window.location.href = "index.html"; // Si no hay sesión, volver al login
    return;
  }

  document.getElementById("username").textContent = user.name;
  document.getElementById("robux").textContent = "💰 0"; // Por ahora fijo

  loadFriends(user);
};

// Cerrar sesión
function logout() {
  sessionStorage.removeItem("currentUser");
  window.location.href = "index.html";
}

// Navegación entre páginas internas
function showPage(page) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  document.getElementById(page + "Page").classList.add("active");
}

// Ir al perfil del usuario logueado
function goProfile() {
  let user = JSON.parse(sessionStorage.getItem("currentUser"));
  if (user) {
    window.location.href = `profile.html#user=${user.id}`;
  }
}

// Mostrar amigos en home
function loadFriends(user) {
  let users = JSON.parse(localStorage.getItem("users")) || {};
  let list = document.getElementById("friendsList");
  if (!list) return;

  list.innerHTML = "";
  if (user.friends.length === 0) {
    list.innerHTML = "<li>No tienes amigos todavía.</li>";
    return;
  }

  user.friends.forEach(fid => {
    let friendName = Object.keys(users).find(u => users[u].id === fid);
    if (friendName) {
      let li = document.createElement("li");
      li.textContent = friendName;
      list.appendChild(li);
    }
  });
}